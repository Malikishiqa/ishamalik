// // // Assigenment 1//


// //FirstName//
// let firtsNumber = prompt("Enter the first number:");
// //SecondName//
// let secondNumber = prompt("Enter the second number:");
// //ParseFloat Function//
// let num1 = parseFloat(firtsNumber);
// let num2 = parseInt(secondNumber);
// //Sum number//
// let sum = num1 + num2;
// alert("The sum is: " + sum);
// //Difference number//
// let difference = num1 - num2;
// alert("The difference is:" + difference);
// //Multipilication//
// let product = num1 * num2;
// alert("The product is: " + product);
// //If Statement//
// if (num2 !== 0){
//     let division =num1/num2;
//     alert(`The division result is:${division} `);
// }
// //Else Statement//
// else{
//     alert("Cannot divided by zero. please enter a non-zero second number.");
// }




//Assignment 2//


// let totalAge = 0;
// const numStudents = 10;
// //For Loop//
// for (let i = 0; i < numStudents; i++) {
//     let age = parseInt(prompt(`Enter the age of student:${i+1}`));
   
//     totalAge += age;
// }
// //Avereage Age//
// let averageAge = totalAge / numStudents;
// alert(`The average age of the class is: ${averageAge}`);

//Assignmemnt3//


// //Radius//
// const radius = parseFloat(prompt("Enter the radius of the circle:"));
// //Diameter//
// const diameter = 2 * radius;
// //Circumference//
// const circumference = 2 * Math.PI * radius;
// //Area//
// const area = Math.PI * radius ** 2;
// //Print On The Screen//
// alert(`Diameter: ${diameter.toFixed(2)}`);
// alert(`Circumference: ${circumference.toFixed(2)}`);
// alert(`Area: ${area.toFixed(2)} `);


//Assignment 4//


// //BillAmount//
// const billAmount = parseFloat(prompt("Enter the bill amount"));
// //Discount//
// let discount;
// //Greater Then//
// if(billAmount>5000){
//     discount = 0.15;
// }
// //Less then//
// else{
//     discount = 0.1;
// }
// //TotalAmount//
// const payableAmount = billAmount - (billAmount * discount);
// //Print On The Screen//
// alert(`The payable amount is: $${payableAmount.toFixed(2)}`);


//Assignment5//


// //Height//
// let height = parseFloat(prompt("Enter your height in inches:"));
// //Weight//
// let weight = parseFloat(prompt("Enter your weight in pounds:"));
// //Bmi Formulla//
// let bmi = (weight * 703) / (height * height);
// //Categories//
// let bmiCategory;
// if (bmi < 16.0){bmiCategory = "Severely Underweight";}
// else if (bmi >= 16.0 && bmi <= 18.4){bmiCategory = "Underweight";}
// else if (bmi >=18.5 && bmi <=24.9){bmiCategory = "Normal";}
// else if (bmi >=25.0 && bmi <=29.9){bmiCategory = "Overweight";}
// else if (bmi >=30.0 && bmi <=34.9){bmiCategory = "Moderetely Obese";}
// else if (bmi >=35.0 && bmi <=39.9){bmiCategory = "Severely Obese";}
// else{ bmiCategory = "Morbidly Obese";}
// //Print On The Screen//
// alert(`Your BMI is ${bmi.toFixed(1)},which is considered ${bmiCategory}.`);

//Assignment6//


// //prompt//
// let userage = prompt("what is your age?");
// //check the userage//
// if(userage<18){alert("Sorry, you are too young to drive to drive this car.Powering off");}
// else if(userage===18){alert("Congratulations on your first year of driving.Enjoy the ride");}
// else{alert("Powering On.Enjoy the ride!")}


//Assignment7//


// console.log("*Welcome to our online shop*");
// //ItemName//
// const itemName = prompt("What item are you buying?");
// //ItemPrice//
// const itemPrice = parseFloat(prompt("What is the price of the item?"));
// //ItemQuantity//
// const itemQuantity = parseInt(prompt("How many of this item are you purchasing?"));
// //SubTotal//
// const subtotal = itemPrice * itemQuantity;
// alert(`You are purchasing ${itemQuantity} ${itemName}(s) at ${itemPrice} Your subtotal is ${subtotal.toFixed(2)}.`);



//Assignment8//


// //Promot//
// let tweet = prompt("Enter your tweet:");
// let tweetLength = tweet.length;
// //Less Than or Equal To Opertor//
// if (tweetLength <= 140){
//  alert(`Your ${tweetLength} char tweet will work!`);
// }
// else{
//    alert(`Your ${tweetLength} char tweet is ${tweetLength - 140} chars too long `);
// }

//Assignment9//


// //Four Digit Integer//
// let userInput = prompt("Please enter a four-digit integar:");
// // Not Strictly Equal To function, OR Logic//
// if(userInput.length !== 4 || isNaN(userInput)){
//     console.log("Please enter a valid four-digit integer.");
// }
// else{
//     let digits =userInput.split('').map(Number);
//     digits.forEach(digit => {
//      alert(digit);
//     });
// }



//Assignment10//



//  //Temperature//
//  let temperature = 25; 
//  //Greater Than Operator//
//  if(temperature > 30){
//     console.log("Don't forget the factor 50!");
//  }
//  //Less Than Opertor//
//  else if (temperature < 10){
//    console.log ("Weara jacket today!");
//  }
//  //Print On The Screen//
//  else{
//     alert("It's a T-shirt kind of day! ");

//  }
 

//Assignment11//


//For Loop//
// for (let i = 1; i <= 100; i++){
//     if (i % 3 === 0 && i % 5 === 0){alert('fizz buzz');
//     }
//     else if (i % 3 === 0){
//         alert('fizz');
//     }
//     else if(i % 5 === 0){
//         alert("buzz");
//     }
//     else {
//         alert(i);
//     }
// }

//Assignment12//



// function colorMessage(favoriteColor,shirtColor){
//     if(favoriteColor===shirtColor){
//         return 'The shirt is your favorit color!';
//     }
//     else{
//         return 'That is a nice color.';
//     }
// }
//    alert(colorMessage('red','red'));
// alert(colorMessage('pink','orange'));

//Assignment13//


// function isEven(num){
//     return num % 2===0;
// }
// alert(isEven(8));
// alert(isEven(3));
// alert(isEven(10));
// alert(isEven(7));
// alert(isEven(14));
// alert(isEven(13));


//Assignment14//


// function capitalization(str){
//     let firstChar = str.charAt(0).toUpperCase();
//     let restString = str.slice(1);
//     return firstChar + restString;
// }
// console.log(capitalization('eggplant'));
// console.log(capitalization('pamplemousse'));
// console.log(capitalization('squid'));








//Assignment15//


// function multiply(a,b){
//     return a * b;
// }
// alert(multiply(2,3));
// alert(multiply(9,9));
// alert(multiply(5,4));

//Assignment16//


// function lifePhase(age){
//     if (age<0 || age>140)
//     {return 'This is not a valid age';}
//     else if (age<=3){
//         return 'baby';}
//         else if(age<=12){
//             return 'child';
//         }
//         else if(age<=19){
//             return 'teen';
//         }
//         else if (age<=64){
//             return 'adult';
//         }
//         else{
//             return 'senior citizen';
//         }
//     }
//     console.log(lifePhase(2));
//     console.log(lifePhase(16));
//     console.log(lifePhase(65));
    // console.log(lifePhase(150));

    //Assignment17//


//     function finalGrade(grade1,grade2,grade3){
//     if(grade1<0 ||grade1>100 || grade2<0 || grade2>100|| grade3<0||grade3>100){
//         return 'Tou have entered an invaild garde.';
//     }
//     let average =(grade1+grade2+grade3)/3;
//     if(average>=90){
//         return'A';
//     }
//     else if (average>=80){
//         return'B';
//     }
//     else if (average>=70){
//         return 'C'
//     }
//     else if (average>=60){
//         return'D';
//     }
//     else{
//         return 'F';
//     }
// }
// console.log(finalGrade(80,90,70));
// console.log(finalGrade(40,50,60));
// console.log(finalGrade(70,80,90));
// console.log(finalGrade(100,90,80));
// console.log(finalGrade(-10,90,90));


//Assignment18//


// function reverseArray(arr){
//     const reverseArr=[];
//     for (let i=arr.length - 1; i>=0; i--){
//     reverseArray.push(arr[i]);
// }
// return reverseArr;
// }
// const sentence = ['sense. make','all','will','This'];{
// console.log(reverseArray(sentence));}






